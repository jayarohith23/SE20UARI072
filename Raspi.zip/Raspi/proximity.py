import time
import board
import busio
import adafruit_vcnl4010

# Initialize I2C bus
i2c = busio.I2C(board.SCL, board.SDA)

# Initialize the VCNL4010 sensor
sensor = adafruit_vcnl4010.VCNL4010(i2c)

while True:
    # Read proximity data
    proximity = sensor.proximity

    # Print the proximity data
    print(f"Proximity: {proximity}")

    # Wait for a moment before the next reading
    time.sleep(1)
